-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 18, 2021 at 12:32 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rk_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `sno` int(3) NOT NULL AUTO_INCREMENT,
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `balance` int(8) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`sno`, `sender`, `receiver`, `balance`, `datetime`) VALUES
(1, 'Kiran', 'alen', 2000, '2021-07-18 16:17:13'),
(2, 'ammu', 'arjun', 500, '2021-07-18 16:17:38'),
(3, 'Kiran', 'arjun', 2000, '2021-07-18 16:21:13'),
(4, 'arjun', 'gamad', 500, '2021-07-18 16:57:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `balance` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=54655 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `balance`) VALUES
(1, 'Kiran', 'kiran@gmail.com', 45500),
(2, 'john', 'john@gmail.com', 45002),
(3, 'alen', 'alen@gmail.com', 42000),
(4, 'ammu', 'ammu@gmail.com', 48280),
(5, 'archana', 'archana@gmail.com', 34560),
(6, 'Alka', 'alka@gmail.com', 4950),
(7, 'ram', 'ram@gmail.com', 11000),
(8, 'gamad', 'gamad@gmail.com', 4950),
(9, 'arjun', 'arjun@gmail.com', 2500),
(10, 'Sachin', 'sach@gmail.com', 3000);
